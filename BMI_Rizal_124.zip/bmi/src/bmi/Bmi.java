package bmi;
public class Bmi {
    public static void main(String[] args) {
        // TODO code application logic here
        int beratbadan = 70;
        float tinggibadan =1.80f;
        float bmi=(beratbadan/ (tinggibadan*tinggibadan));
        
        System.out.println("BMI ANDA ADALAH\t:"+bmi);
        
        if (bmi<18.5){
            System.out.println("BERAT BADAN ANDA KURANG");
        }    
        else if (bmi<24.0){
            System.out.println("BERAT BADAN ANDA IDEAL/NORMAL");
        }
        else if (bmi<29.9){
            System.out.println("BERAT BADAN ANDA LEBIH");
        }
        else{
        }
        System.out.println("OBESITAS");
        }
    } 

        
    